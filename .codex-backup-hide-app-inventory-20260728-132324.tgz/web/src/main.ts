import { createApp } from 'vue'
import { createPinia } from 'pinia'
import ElementPlus from 'element-plus'
import zhCn from 'element-plus/dist/locale/zh-cn.mjs'
import 'element-plus/dist/index.css'
import './style.css'
import * as ElementPlusIconsVue from '@element-plus/icons-vue'
import App from './App.vue'
import router, { registerPluginRoutes } from './router'
import { pluginManager } from './plugins/manager'
import { installReadonlyGuards } from './utils/readonly'

// 导入插件（插件会自动注册到 pluginManager）
import '@/plugins/kubernetes'
import '@/plugins/monitor'
import '@/plugins/logcenter'
import '@/plugins/nginx'
import '@/plugins/task'
import '@/plugins/test'
import '@/plugins/ssl-cert'
import '@/plugins/app-inventory'

const app = createApp(App)
const pinia = createPinia()

// 注册所有图标
for (const [key, component] of Object.entries(ElementPlusIconsVue)) {
  app.component(key, component)
}

app.use(pinia)

// 自动安装所有已注册的插件
async function installPlugins() {
  const plugins = pluginManager.getAll()

  for (const plugin of plugins) {
    await pluginManager.install(plugin.name, false) // 不显示消息
  }
}

// 安装插件并注册路由
installPlugins().then(() => {
  // 注册插件路由 - 必须在 app.use(router) 之前
  registerPluginRoutes()

  app.use(router)
  app.use(ElementPlus, {
    locale: zhCn,
  })

  installReadonlyGuards()

  app.mount('#app')
})
