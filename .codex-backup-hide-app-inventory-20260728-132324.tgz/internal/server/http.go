// Copyright (c) 2026 DYCloud J.
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of
// this software and associated documentation files (the "Software"), to deal in
// the Software without restriction, including without limitation the rights to
// use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
// the Software, and to permit persons to whom the Software is furnished to do so,
// subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
// FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
// COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
// IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
// CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

package server

import (
	"context"
	"fmt"
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
	swaggerFiles "github.com/swaggo/files"
	ginSwagger "github.com/swaggo/gin-swagger"
	mfabiz "github.com/ydcloud-dy/opshub/internal/biz/mfa"
	"github.com/ydcloud-dy/opshub/internal/conf"
	mfadata "github.com/ydcloud-dy/opshub/internal/data/mfa"
	rbacdata "github.com/ydcloud-dy/opshub/internal/data/rbac"
	"github.com/ydcloud-dy/opshub/internal/plugin"
	aiopsserver "github.com/ydcloud-dy/opshub/internal/server/aiops"
	assetserver "github.com/ydcloud-dy/opshub/internal/server/asset"
	auditserver "github.com/ydcloud-dy/opshub/internal/server/audit"
	identityserver "github.com/ydcloud-dy/opshub/internal/server/identity"
	mfaserver "github.com/ydcloud-dy/opshub/internal/server/mfa"
	"github.com/ydcloud-dy/opshub/internal/server/rbac"
	systemserver "github.com/ydcloud-dy/opshub/internal/server/system"
	"github.com/ydcloud-dy/opshub/internal/service"
	mfaservice "github.com/ydcloud-dy/opshub/internal/service/mfa"
	rbacservice "github.com/ydcloud-dy/opshub/internal/service/rbac"
	appLogger "github.com/ydcloud-dy/opshub/pkg/logger"
	"github.com/ydcloud-dy/opshub/pkg/middleware"
	appinventoryplugin "github.com/ydcloud-dy/opshub/plugins/app-inventory"
	k8splugin "github.com/ydcloud-dy/opshub/plugins/kubernetes"
	logcenterplugin "github.com/ydcloud-dy/opshub/plugins/logcenter"
	logcenterserver "github.com/ydcloud-dy/opshub/plugins/logcenter/server"
	monitorplugin "github.com/ydcloud-dy/opshub/plugins/monitor"
	nginxplugin "github.com/ydcloud-dy/opshub/plugins/nginx"
	sslcertplugin "github.com/ydcloud-dy/opshub/plugins/ssl-cert"
	taskplugin "github.com/ydcloud-dy/opshub/plugins/task"
	"go.uber.org/zap"
	"gorm.io/gorm"
)

// HTTPServer HTTP服务器
type HTTPServer struct {
	server    *http.Server
	conf      *conf.Config
	svc       *service.Service
	db        *gorm.DB
	pluginMgr *plugin.Manager
	uploadSrv *UploadServer
}

// NewHTTPServer 创建HTTP服务器
func NewHTTPServer(conf *conf.Config, svc *service.Service, db *gorm.DB) *HTTPServer {
	// 设置Gin模式
	gin.SetMode(conf.Server.Mode)

	// 创建路由
	router := gin.New()

	// 使用中间件
	router.Use(middleware.Logger())
	router.Use(middleware.Recovery())
	router.Use(middleware.CORS())
	router.Use(captureExternalURL())
	router.Use(middleware.AuditLogOperation(db))

	// 创建插件管理器
	pluginMgr := plugin.NewManager(db)

	// 创建上传服务
	uploadDir := "./web/public/uploads"
	uploadURL := "/uploads"
	uploadSrv := NewUploadServer(db, uploadDir, uploadURL)

	// 注册 Kubernetes 插件
	if err := pluginMgr.Register(k8splugin.New()); err != nil {
		appLogger.Error("注册Kubernetes插件失败", zap.Error(err))
	}

	// 注册 Task 插件
	if err := pluginMgr.Register(taskplugin.New()); err != nil {
		appLogger.Error("注册Task插件失败", zap.Error(err))
	}

	// 注册 Monitor 插件
	if err := pluginMgr.Register(monitorplugin.New()); err != nil {
		appLogger.Error("注册Monitor插件失败", zap.Error(err))
	}

	// 注册应用资产中心插件
	if err := pluginMgr.Register(appinventoryplugin.New()); err != nil {
		appLogger.Error("注册应用资产中心插件失败", zap.Error(err))
	}

	// 注册 LogCenter 插件
	if err := pluginMgr.Register(logcenterplugin.New()); err != nil {
		appLogger.Error("注册LogCenter插件失败", zap.Error(err))
	}

	// 注册 Nginx 插件
	if err := pluginMgr.Register(nginxplugin.New()); err != nil {
		appLogger.Error("注册Nginx插件失败", zap.Error(err))
	}

	// 注册 ssl-cert 插件
	if err := pluginMgr.Register(sslcertplugin.New()); err != nil {
		appLogger.Error("注册ssl-cert插件失败", zap.Error(err))
	}

	// 注册路由
	s := &HTTPServer{
		conf:      conf,
		svc:       svc,
		db:        db,
		pluginMgr: pluginMgr,
		uploadSrv: uploadSrv,
	}

	// 先启用所有插件（在注册路由之前）
	s.enablePlugins()

	// 注册路由（插件启用后才能注册路由）
	s.registerRoutes(router, conf.Server.JWTSecret)

	// 创建HTTP服务器
	s.server = &http.Server{
		Addr:         fmt.Sprintf(":%d", conf.Server.HttpPort),
		Handler:      router,
		ReadTimeout:  time.Duration(conf.Server.ReadTimeout) * time.Millisecond,
		WriteTimeout: time.Duration(conf.Server.WriteTimeout) * time.Millisecond,
	}

	return s
}

// registerRoutes 注册路由
func (s *HTTPServer) registerRoutes(router *gin.Engine, jwtSecret string) {
	// Swagger 文档
	router.GET("/swagger/*any", ginSwagger.WrapHandler(swaggerFiles.Handler))

	// 健康检查
	router.GET("/health", s.svc.Health)

	// 静态文件服务 - 上传的文件
	router.Static("/uploads", "./web/public/uploads")

	// 创建 RBAC 服务
	userService, roleService, departmentService, menuService, positionService, captchaService, assetPermissionService, authMiddleware := rbac.NewRBACServices(s.db, jwtSecret)

	// RBAC 路由
	rbacServer := rbac.NewHTTPServer(userService, roleService, departmentService, menuService, positionService, captchaService, assetPermissionService, authMiddleware)
	rbacServer.RegisterRoutes(router)

	// 创建 System 服务
	uploadDir := "./web/public/uploads"
	configService, configUseCase := systemserver.NewSystemServices(s.db, uploadDir)

	// 设置配置用例到用户服务（用于密码验证和登录锁定）
	userService.SetConfigUseCase(configUseCase)

	// 创建并注入LDAP认证服务
	ldapAuthService := rbacservice.NewLDAPAuthService(configUseCase, userService.GetUserUseCase())
	userService.SetLDAPAuthService(ldapAuthService)

	// 创建 MFA 服务
	mfaRepo := mfadata.NewRepository(s.db)
	mfaUseCase := mfabiz.NewUseCase(mfaRepo, "OpsHub", []byte(jwtSecret))
	userService.SetMFAUseCase(mfaUseCase)

	// MFA HTTP服务
	mfaService := mfaservice.NewService(mfaUseCase, userService.GetAuthService(), userService.GetUserUseCase())
	mfaHTTPServer := mfaserver.NewHTTPServer(mfaService)
	mfaHTTPServer.SetConfigUseCase(configUseCase)

	// 创建 Audit 服务
	operationLogService, loginLogService, dataLogService := auditserver.NewAuditServices(s.db)

	// 创建 Asset 服务
	assetGroupService, hostService, terminalManager := assetserver.NewAssetServices(s.db)

	// 设置authMiddleware的assetPermissionRepo
	assetPermissionRepo := rbacdata.NewAssetPermissionRepo(s.db)
	authMiddleware.SetAssetPermissionRepo(assetPermissionRepo)

	// Asset 路由
	assetServer := assetserver.NewHTTPServer(assetGroupService, hostService, terminalManager, s.db, authMiddleware)

	// API v1 - 公开接口(不需要认证)
	public := router.Group("/api/v1/public")
	{
		public.GET("/example", s.svc.Example)
		assetServer.RegisterPublicRoutes(public)
		logcenterserver.RegisterPublicRoutes(public, s.db)
	}

	identityServer, err := identityserver.NewIdentityServices(s.db, s.conf)
	if err != nil {
		appLogger.Error("创建Identity服务失败", zap.Error(err))
	} else {
		identityServer.RegisterPublicRoutes(public)
	}

	// API v1 - 需要认证的接口
	v1 := router.Group("/api/v1")
	v1.Use(authMiddleware.AuthRequired())
	v1.Use(authMiddleware.ReadonlyUserRequired())
	{
		// Audit 路由
		auditHTTPServer := auditserver.NewHTTPService(operationLogService, loginLogService, dataLogService)
		auditHTTPServer.RegisterRoutes(v1)

		// 注册 Asset 路由
		assetServer.RegisterRoutes(v1)

		// 智能运维路由（内置模块，非插件）
		aiopsHTTPServer := aiopsserver.NewHTTPServer(s.db, authMiddleware)
		aiopsHTTPServer.RegisterRoutes(v1)

		if identityServer != nil {
			identityServer.RegisterRoutes(v1)
			identityServer.RegisterOAuth2Routes(router, authMiddleware.AuthRequired, authMiddleware.OptionalAuth)
		}

		// 上传接口
		v1.POST("/upload/avatar", s.uploadSrv.UploadAvatar)
		v1.PUT("/profile/avatar", s.uploadSrv.UpdateUserAvatar)

		// 系统配置路由
		systemHTTPServer := systemserver.NewHTTPServer(configService)
		systemHTTPServer.RegisterRoutes(v1, public)

		// MFA 路由
		mfaHTTPServer.RegisterRoutes(v1)
	}

	// 插件路由
	pluginsGroup := router.Group("/api/v1/plugins")
	pluginsGroup.Use(authMiddleware.AuthRequired())
	pluginsGroup.Use(authMiddleware.ReadonlyUserRequired())
	s.pluginMgr.RegisterAllRoutes(pluginsGroup)

	// 插件管理接口
	pluginInfoGroup := router.Group("/api/v1/plugins")
	pluginInfoGroup.Use(authMiddleware.AuthRequired())
	pluginInfoGroup.Use(authMiddleware.ReadonlyUserRequired())
	{
		pluginInfoGroup.GET("", s.listPlugins)
		pluginInfoGroup.GET("/:name", s.getPlugin)
		pluginInfoGroup.GET("/:name/menus", s.getPluginMenus)
		pluginInfoGroup.POST("/:name/enable", s.enablePlugin)
		pluginInfoGroup.POST("/:name/disable", s.disablePlugin)
		pluginInfoGroup.POST("/upload", s.uploadSrv.UploadPlugin)
		pluginInfoGroup.DELETE("/:name/uninstall", s.uploadSrv.UninstallPlugin)
	}

	// 前端静态文件服务（后面会用到）
	// router.Static("/assets", "./web/dist/assets")
	// router.NoRoute(func(c *gin.Context) {
	//     c.File("./web/dist/index.html")
	// })
}

// enablePlugins 启用所有已注册的插件
func (s *HTTPServer) enablePlugins() {
	for _, p := range s.pluginMgr.GetAllPlugins() {
		if err := s.pluginMgr.Enable(p.Name()); err != nil {
			appLogger.Error("启用插件失败",
				zap.String("plugin", p.Name()),
				zap.Error(err),
			)
		} else {
			appLogger.Info("插件启用成功",
				zap.String("plugin", p.Name()),
				zap.String("version", p.Version()),
			)
		}
	}
}

// listPlugins 获取所有插件列表
// @Summary 获取插件列表
// @Description 获取系统中所有已注册的插件列表
// @Tags 插件管理
// @Accept json
// @Produce json
// @Security Bearer
// @Success 200 {object} map[string]interface{} "插件列表"
// @Router /api/v1/plugins [get]
func (s *HTTPServer) listPlugins(c *gin.Context) {
	plugins := s.pluginMgr.GetAllPlugins()
	result := make([]map[string]interface{}, 0, len(plugins))

	for _, p := range plugins {
		enabled := s.pluginMgr.IsEnabled(p.Name())
		appLogger.Info("获取插件状态",
			zap.String("plugin", p.Name()),
			zap.Bool("enabled", enabled),
		)
		result = append(result, map[string]interface{}{
			"name":        p.Name(),
			"description": p.Description(),
			"version":     p.Version(),
			"author":      p.Author(),
			"enabled":     enabled,
		})
	}

	appLogger.Info("返回插件列表", zap.Int("count", len(result)))
	c.JSON(200, gin.H{
		"code":    0,
		"message": "success",
		"data":    result,
	})
}

// getPlugin 获取插件详情
// @Summary 获取插件详情
// @Description 获取指定插件的详细信息
// @Tags 插件管理
// @Accept json
// @Produce json
// @Security Bearer
// @Param name path string true "插件名称"
// @Success 200 {object} map[string]interface{} "插件详情"
// @Failure 404 {object} map[string]interface{} "插件不存在"
// @Router /api/v1/plugins/{name} [get]
func (s *HTTPServer) getPlugin(c *gin.Context) {
	name := c.Param("name")
	plugin, exists := s.pluginMgr.GetPlugin(name)
	if !exists {
		c.JSON(404, gin.H{
			"code":    404,
			"message": "plugin not found",
		})
		return
	}

	c.JSON(200, gin.H{
		"code":    0,
		"message": "success",
		"data": map[string]interface{}{
			"name":        plugin.Name(),
			"description": plugin.Description(),
			"version":     plugin.Version(),
			"author":      plugin.Author(),
			"enabled":     s.pluginMgr.IsEnabled(name),
		},
	})
}

// getPluginMenus 获取插件的菜单配置
// @Summary 获取插件菜单
// @Description 获取指定插件的菜单配置信息
// @Tags 插件管理
// @Accept json
// @Produce json
// @Security Bearer
// @Param name path string true "插件名称"
// @Success 200 {object} map[string]interface{} "菜单配置"
// @Failure 404 {object} map[string]interface{} "插件不存在"
// @Router /api/v1/plugins/{name}/menus [get]
func (s *HTTPServer) getPluginMenus(c *gin.Context) {
	name := c.Param("name")
	plugin, exists := s.pluginMgr.GetPlugin(name)
	if !exists {
		c.JSON(404, gin.H{
			"code":    404,
			"message": "plugin not found",
		})
		return
	}

	menus := plugin.GetMenus()
	c.JSON(200, gin.H{
		"code":    0,
		"message": "success",
		"data":    menus,
	})
}

// enablePlugin 启用插件
// @Summary 启用插件
// @Description 启用指定的插件
// @Tags 插件管理
// @Accept json
// @Produce json
// @Security Bearer
// @Param name path string true "插件名称"
// @Success 200 {object} map[string]interface{} "启用成功"
// @Failure 500 {object} map[string]interface{} "启用失败"
// @Router /api/v1/plugins/{name}/enable [post]
func (s *HTTPServer) enablePlugin(c *gin.Context) {
	name := c.Param("name")

	if err := s.pluginMgr.Enable(name); err != nil {
		appLogger.Error("启用插件失败",
			zap.String("plugin", name),
			zap.Error(err),
		)
		c.JSON(500, gin.H{
			"code":    500,
			"message": fmt.Sprintf("启用插件失败: %v", err),
		})
		return
	}

	appLogger.Info("插件启用成功", zap.String("plugin", name))
	c.JSON(200, gin.H{
		"code":    0,
		"message": "插件启用成功，请刷新页面以生效",
	})
}

// disablePlugin 禁用插件
// @Summary 禁用插件
// @Description 禁用指定的插件
// @Tags 插件管理
// @Accept json
// @Produce json
// @Security Bearer
// @Param name path string true "插件名称"
// @Success 200 {object} map[string]interface{} "禁用成功"
// @Failure 500 {object} map[string]interface{} "禁用失败"
// @Router /api/v1/plugins/{name}/disable [post]
func (s *HTTPServer) disablePlugin(c *gin.Context) {
	name := c.Param("name")

	if err := s.pluginMgr.Disable(name); err != nil {
		appLogger.Error("禁用插件失败",
			zap.String("plugin", name),
			zap.Error(err),
		)
		c.JSON(500, gin.H{
			"code":    500,
			"message": fmt.Sprintf("禁用插件失败: %v", err),
		})
		return
	}

	appLogger.Info("插件禁用成功", zap.String("plugin", name))
	c.JSON(200, gin.H{
		"code":    0,
		"message": "插件禁用成功，请刷新页面以生效",
	})
}

// Start 启动服务器
func (s *HTTPServer) Start() error {
	appLogger.Info("HTTP服务器启动",
		zap.String("addr", s.server.Addr),
		zap.String("mode", s.conf.Server.Mode),
	)

	if err := s.server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
		return fmt.Errorf("HTTP服务器启动失败: %w", err)
	}

	return nil
}

// Stop 停止服务器
func (s *HTTPServer) Stop(ctx context.Context) error {
	appLogger.Info("HTTP服务器停止中...")
	if err := s.server.Shutdown(ctx); err != nil {
		return fmt.Errorf("HTTP服务器停止失败: %w", err)
	}
	appLogger.Info("HTTP服务器已停止")
	return nil
}
